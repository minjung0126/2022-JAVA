package com.chicken.project.exception.order;

public class InterestException extends Exception {

    public InterestException() {
    }

    public InterestException(String message) {
        super(message);
    }


}

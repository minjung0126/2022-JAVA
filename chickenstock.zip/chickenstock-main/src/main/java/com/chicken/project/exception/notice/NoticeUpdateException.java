package com.chicken.project.exception.notice;

public class NoticeUpdateException extends Exception{

    public NoticeUpdateException() {}

    public NoticeUpdateException(String msg) {
        super(msg);
    }
}

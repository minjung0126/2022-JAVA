package com.chicken.project.member.model.service;

import org.springframework.security.core.userdetails.UserDetailsService;


public interface MemberService extends UserDetailsService{

}

package com.chicken.project.billTax.model.dao;

public interface TsBillMapper {
}

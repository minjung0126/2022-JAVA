package com.chicken.project.exception.item;

public class ItemInsertException extends Exception{

    public ItemInsertException() {
    }

    public ItemInsertException(String msg) {
        super(msg);
    }
}

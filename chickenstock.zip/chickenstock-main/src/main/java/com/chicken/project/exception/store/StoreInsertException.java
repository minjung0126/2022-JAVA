package com.chicken.project.exception.store;

public class StoreInsertException extends Exception{

    public StoreInsertException(){}

    public StoreInsertException(String msg){
        super(msg);
    }
}

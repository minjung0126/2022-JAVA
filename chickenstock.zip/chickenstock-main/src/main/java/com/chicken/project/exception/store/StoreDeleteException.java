package com.chicken.project.exception.store;

public class StoreDeleteException extends Exception{

    public StoreDeleteException(){}

    public StoreDeleteException(String msg){
        super(msg);
    }
}

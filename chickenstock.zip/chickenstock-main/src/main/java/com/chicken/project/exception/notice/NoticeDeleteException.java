package com.chicken.project.exception.notice;

public class NoticeDeleteException extends Exception{

    public NoticeDeleteException(){}

    public NoticeDeleteException(String msg){
        super(msg);
    }
}

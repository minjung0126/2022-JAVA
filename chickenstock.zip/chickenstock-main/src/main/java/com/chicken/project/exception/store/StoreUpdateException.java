package com.chicken.project.exception.store;

public class StoreUpdateException extends Exception{

    public StoreUpdateException(){}

    public StoreUpdateException(String msg){
        super(msg);
    }
}

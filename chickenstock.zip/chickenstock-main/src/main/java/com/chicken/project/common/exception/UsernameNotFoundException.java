package com.chicken.project.common.exception;

public class UsernameNotFoundException extends Exception{

    public UsernameNotFoundException(String msg){
        super(msg);
    }
}

package com.chicken.project.exception.notice;

public class NoticeInsertException extends Exception{

    public NoticeInsertException() {}

    public NoticeInsertException(String msg) {
        super(msg);
    }
}

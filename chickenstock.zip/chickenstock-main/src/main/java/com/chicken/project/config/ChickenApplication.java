package com.chicken.project.config;

        import org.springframework.boot.SpringApplication;
        import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChickenApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChickenApplication.class, args);

    }

}

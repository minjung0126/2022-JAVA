package com.chicken.project.billTax.model.dto;

public class TsBillDTO {
}

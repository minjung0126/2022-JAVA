package com.chicken.project.exception.receive;

public class ReceiveInsertException extends Exception{

    public ReceiveInsertException() {
    }

    public ReceiveInsertException(String msg) {
        super(msg);
    }
}

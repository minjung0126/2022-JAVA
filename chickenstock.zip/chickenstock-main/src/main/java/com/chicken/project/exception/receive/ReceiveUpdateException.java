package com.chicken.project.exception.receive;

public class ReceiveUpdateException extends Exception{

    public ReceiveUpdateException() {
    }
    public ReceiveUpdateException(String msg) {
        super(msg);
    }
}

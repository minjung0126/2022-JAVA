package com.chicken.project.exception.item;

public class ItemUpdateException extends Exception {

    public ItemUpdateException() {
    }

    public ItemUpdateException(String msg) {
        super(msg);
    }
}

package com.chicken.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChickenApplicationTests {

    @Test
    void contextLoads() {
    }

}
